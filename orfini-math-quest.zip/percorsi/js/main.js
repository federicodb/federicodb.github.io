// Orfini Math Quest — avvio e navigazione.
import * as G from './game/game.js';
import { app } from './app.js';
import { loadCAS } from './engine/cas.js';
import { viewOnboarding } from './screens/onboarding.js';
import { viewHome } from './screens/home.js';
import { startLesson, startReview } from './screens/play.js';
import { viewChallenges, startLampo, viewEnigma, startSimulation } from './screens/challenges.js';
import { viewLeague } from './screens/league.js';
import { viewRewards } from './screens/rewards.js';
import { viewProfile } from './screens/profile.js';
import { viewTeacher } from './screens/teacher.js';

app.state = G.load(app.store, app.today());
app.applySettings();
const startEvents = G.rollover(app.state, app.today());
app.save();

// i motori simbolici si caricano dopo la prima schermata, senza rallentarla
setTimeout(() => loadCAS(), 1200);

function route() {
  app.stopLesson?.();
  app.stopLesson = null;
  document.body.classList.remove('in-lesson');
  document.querySelectorAll('.sheet-backdrop').forEach((n) => n.remove());
  // cambio di giorno con la pagina aperta
  app.handle(G.rollover(app.state, app.today()));
  app.save();
  const [view, a, b] = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  if (!app.state.onboarded && view !== 'docente') {
    viewOnboarding(app);
    app.chrome();
    return;
  }
  app.chrome();
  switch (view) {
    case 'lezione': startLesson(app, a, +b || 1); break;
    case 'ripasso': startReview(app); break;
    case 'sfide': viewChallenges(app); break;
    case 'lampo': startLampo(app); break;
    case 'enigma': viewEnigma(app); break;
    case 'simulazione': startSimulation(app, +a === 13 ? 13 : 10); break;
    case 'lega': viewLeague(app); break;
    case 'premi': viewRewards(app, a || 'pass'); break;
    case 'profilo': viewProfile(app, a); break;
    case 'docente': viewTeacher(app); break;
    case 'benvenuto': app.state.onboarded = false; app.save(); viewOnboarding(app); break;
    default: viewHome(app);
  }
  if (!document.body.classList.contains('in-lesson')) { window.scrollTo({ top: 0 }); setTimeout(() => { if (!app._modalBusy && !document.body.classList.contains('in-lesson')) app.flushModals(); }, 300); }
  app.main.focus({ preventScroll: true });
}

window.addEventListener('hashchange', route);
route();
app.handle(startEvents);
