from fullcontrol.gcode import Point, Printer, Extruder, ManualGcode, PrinterCommand, GcodeComment, Buildplate, Hotend, Fan
import fullcontrol.devices.community.singletool.base_settings as base_settings


def set_up(user_overrides: dict):
    """Profilo Bambu Lab A1 (256x256x256 mm, Bed-slinger, AMS lite 4 slot).
    Leggero e 100% compatibile con Bambu Studio (nessun StationaryExtrusion da fermo né G92 nascosti).
    """
    printer_overrides = {
        "primer": "front_lines_then_x",
        "print_speed": 2400,
        "travel_speed": 10000,
    }
    initialization_data = {**base_settings.default_initial_settings, **printer_overrides}
    initialization_data = {**initialization_data, **user_overrides}

    ams_slot = int(initialization_data.get("ams_slot", 1))
    tool_idx = max(0, min(3, ams_slot - 1))

    starting_procedure_steps = [
        ManualGcode(text="; FullControl Studio - Bambu Lab A1 (256x256x256 mm)\n"),
        ManualGcode(text=f"; Selected AMS lite Slot: {ams_slot} (Tray {tool_idx})\n"),
        Buildplate(temp=initialization_data["bed_temp"], wait=False),
        Hotend(temp=150, wait=False),
        Buildplate(temp=initialization_data["bed_temp"], wait=True),
        Hotend(temp=initialization_data["nozzle_temp"], wait=True),
        PrinterCommand(id="home"),
        PrinterCommand(id="absolute_coords"),
        PrinterCommand(id="units_mm"),
        Extruder(relative_gcode=initialization_data["relative_e"]),
        Fan(speed_percent=initialization_data["fan_percent"]),
        Extruder(on=False),
        Printer(
            print_speed=initialization_data["print_speed"],
            travel_speed=initialization_data["travel_speed"],
        ),
        Point(x=10.0, y=10.0, z=5.0),
        Point(x=10.0, y=10.0, z=0.25),
        Extruder(on=True),
        ManualGcode(text=f'M220 S{initialization_data["print_speed_percent"]} ; speed factor'),
        ManualGcode(text=f'M221 S{initialization_data["material_flow_percent"]} ; flow factor'),
        ManualGcode(text=";-----\n; END OF STARTING PROCEDURE (A1)\n;-----"),
    ]

    ending_procedure_steps = [
        ManualGcode(text="\n;-----\n; START OF ENDING PROCEDURE (A1)\n;-----"),
        Extruder(on=False),
        ManualGcode(text="G1 E-0.8 F3000 ; retract"),
        ManualGcode(text="G91 ; relative coordinates"),
        ManualGcode(text="G0 Z10 F6000 ; lift nozzle"),
        ManualGcode(text="G90 ; absolute coordinates"),
        Point(x=5.0, y=250.0),
        Fan(speed_percent=0),
        Buildplate(temp=0, wait=False),
        Hotend(temp=0, wait=False),
        ManualGcode(text="M221 S100 ; reset flow"),
        ManualGcode(text="M84 ; disable steppers"),
    ]

    initialization_data["starting_procedure_steps"] = starting_procedure_steps
    initialization_data["ending_procedure_steps"] = ending_procedure_steps
    return initialization_data
